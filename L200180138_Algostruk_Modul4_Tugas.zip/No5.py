class Node(object):
    def __init__ (self, data, next=None):
        self.data = data
        self.next = next

def cari(head, data):
    curHead = head

    while curHead is not None:
        if curHead.data.lower() == data.lower():
            return "Data {} ada".format(curHead.data)
        else:
            curHead = curHead.next
    
    return "Data {} tidak ada".format(data)

a = Node("Budi")
b = Node("Hudi")
c = Node("Mudi")
d = Node("Badi")
e = Node("Mardi")

a.next = b
b.next = c
c.next = d
d.next = e

nama = str(input("Masukkan data yang ingin dicari: "))
print(cari(a, nama))