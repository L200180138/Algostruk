def binse(kumpulan, target):
    low = 0
    high = len(kumpulan)

    hasil = []

    while low < high:
        mid = (high + low) // 2
        if kumpulan[mid] == target:
            while kumpulan[mid -1] == target:
                mid -= 1
            while kumpulan[mid] == target:
                hasil.append(mid)
                mid += 1
                if mid > len(kumpulan)-1:
                    break
            return hasil
        elif target < kumpulan[mid]:
            high = mid - 1
        else:
            low = mid + 1

    return False

a = [2, 3, 5, 6, 6, 6, 8, 9, 9, 10, 11, 12, 13, 13, 14]
print(binse(a, 6))