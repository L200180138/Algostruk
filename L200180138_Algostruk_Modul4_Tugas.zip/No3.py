class Manusia(object):
    """Class 'Manusia' dengan inisiasi 'nama'"""
    keadaan = 'Lapar'
    def __init__(self, nama):
        self.nama = nama

    def ucapkanSalam(self):
        print("Salam, namaku", self.nama)

    def makan(self, s):
        print("Saya baru saja makan", s)
        self.keadaan = "Keyang"

    def olahraga(self, k):
        print("Saya baru saja latihan", k)
        self.keadaan = 'lapar'

    def mengalikanDenganDua(self, n):
        return n*2

class Mahasiswa(Manusia):
    """Class Mahasiswa yang dibangun dari class Manusia"""

    def __init__(self, nama, NIM, kota, us):
        """Metode inisiasi ini menutupi metode inisiasi di class Manusia"""
        self.nama = nama
        self.NIM = NIM
        self.kotaTinggal = kota
        self.uangSaku = us

    def __str__(self):
        s = self.nama + ', NIM ' + str(self.NIM) + ". Tinggal di " + self.kotaTinggal + ". Uang saku Rp " + str(
            self.uangSaku) + ' tiap bulannya.'
        return s

    def ambilNama(self):
        return self.nama

    def ambilNIM(self):
        return self.NIM

    def ambilUangSaku(self):
        return self.uangSaku

    def makan(self, s):
        """Metode ini menutupi metode 'makan' -nya class Manusia.
        Mahasiswa kalau makan sambil belajar"""
        print("Saya baru saja makan", s, "sambil belajar")
        self.keadaan = "kenyang"

def cariUang(daft):
    n = len(daft)
    listMahasiswa = daft

    hasil = [listMahasiswa[0]]

    for i in range(1, n):
        if listMahasiswa[i].uangSaku < hasil[0].uangSaku:
            hasil = [listMahasiswa[i]]
        elif listMahasiswa[i].uangSaku == hasil[0].uangSaku:
            hasil.append(listMahasiswa[i])

    return hasil


c0 = Mahasiswa("Ika", 10, "Sukoharjo", 240000)
c1 = Mahasiswa("Budi", 51, "Sragen", 230000)
c2 = Mahasiswa("Ahmad", 2, "Surakarta", 250000)
c3 = Mahasiswa("Chandra", 18, "Surakarta", 230000)
c4 = Mahasiswa("Eka", 4, "Boyolali", 240000)
c5 = Mahasiswa("Fandi", 31, "Salatiga", 250000)
c6 = Mahasiswa("Deni", 13, "Klaten", 245000)
c7 = Mahasiswa("Galuh", 5, "Wonogiri", 245000)
c8 = Mahasiswa("Janto", 23, "Klaten", 245000)
c9 = Mahasiswa("Hasan", 64, "Karanganyar", 270000)
c10 = Mahasiswa("Khalid", 29, "Purwodadi", 265000)

Daftar = [c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10]

for i in cariUang(Daftar):
    print(i.nama+" jumlah uang saku "+str(i.uangSaku))