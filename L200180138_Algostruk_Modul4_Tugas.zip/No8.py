from random import choice

def jawab(pilih, sumPilih):
    hasil = int(input("Masukkan jawaban ke-1: "))
    for i in range(2, sumPilih+1):
        if hasil == pilih:
            return "Selamat!!! Jawaban {} anda benar".format(hasil)
        else:
            if hasil < pilih:
                print("Jawaban terlalu kecil. Coba lagi")
                hasil = int(input("Masukkan jawaban ke-"+str(i)+": "))
            else:
                print("Jawaban terlalu besar. Coba lagi")
                hasil = int(input("Masukkan jawaban ke-"+str(i)+": "))
    return "{} kesempatan anda udah habis. Coba lagi".format(sumPilih)

a = [i for i in range(1, 100+1)]

select = choice(a)
pilih = 0

if len(a) < 1000:
    pilih = 7
else:
    pilih = 10

print(jawab(select, pilih))