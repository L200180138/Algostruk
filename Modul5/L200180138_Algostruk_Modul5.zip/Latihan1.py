def swap(A, p, q):
    tmp = A[p]
    A[p] = A[q]
    A[q] = tmp

l = [10, 51, 2, 18, 4, 31, 13, 5, 23, 64, 29]
swap(l, 1, 3)
print(l)